<ul class="tabs-nav">
	<li><a href="{{ route('backend.general') }}"><i class="fa fa-cog"></i>{{ __('General') }}</a></li>
	<li><a href="{{ route('backend.theme-register') }}"><i class="fa fa-cog"></i>{{ __('Theme Register') }}</a></li>
	<li><a href="{{ route('backend.google-recaptcha') }}"><i class="fa fa-cog"></i>{{ __('Google reCAPTCHA') }}</a></li>
	<li><a href="{{ route('backend.google-map') }}"><i class="fa fa-cog"></i>{{ __('Google Map') }}</a></li>
	<li><a href="{{ route('backend.mail-settings') }}"><i class="fa fa-cog"></i>{{ __('Mail Settings') }}</a></li>
	<li><a href="{{ route('backend.media-settings') }}"><i class="fa fa-cog"></i>{{ __('Media Settings') }}</a></li>
</ul>