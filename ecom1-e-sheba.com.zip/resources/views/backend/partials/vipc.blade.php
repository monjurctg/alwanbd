
<div class="row mt-15">
	<div class="col-md-12">
		<div class="alert alert-danger" role="alert">
			Please provide valid purchase code. <a class="aclick text-bold" href="{{ route('backend.theme-register') }}">Click Here</a>
		</div>
	</div>
</div>