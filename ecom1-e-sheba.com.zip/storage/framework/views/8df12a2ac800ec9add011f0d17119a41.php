

<?php $__env->startSection('title', __('Cart')); ?>
<?php 
$gtext = gtext();
$gtax = getTax();
?>

<?php $__env->startSection('meta-content'); ?>
	<meta name="keywords" content="<?php echo e($gtext['og_keywords']); ?>" />
	<meta name="description" content="<?php echo e($gtext['og_description']); ?>" />
	<meta property="og:title" content="<?php echo e($gtext['og_title']); ?>" />
	<meta property="og:site_name" content="<?php echo e($gtext['site_name']); ?>" />
	<meta property="og:description" content="<?php echo e($gtext['og_description']); ?>" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo e(url()->current()); ?>" />
	<meta property="og:image" content="<?php echo e(asset('public/media/'.$gtext['og_image'])); ?>" />
	<meta property="og:image:width" content="600" />
	<meta property="og:image:height" content="315" />
	<?php if($gtext['fb_publish'] == 1): ?>
	<meta name="fb:app_id" property="fb:app_id" content="<?php echo e($gtext['fb_app_id']); ?>" />
	<?php endif; ?>
	<meta name="twitter:card" content="summary_large_image">
	<?php if($gtext['twitter_publish'] == 1): ?>
	<meta name="twitter:site" content="<?php echo e($gtext['twitter_id']); ?>">
	<meta name="twitter:creator" content="<?php echo e($gtext['twitter_id']); ?>">
	<?php endif; ?>
	<meta name="twitter:url" content="<?php echo e(url()->current()); ?>">
	<meta name="twitter:title" content="<?php echo e($gtext['og_title']); ?>">
	<meta name="twitter:description" content="<?php echo e($gtext['og_description']); ?>">
	<meta name="twitter:image" content="<?php echo e(asset('public/media/'.$gtext['og_image'])); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
	<!-- Page Breadcrumb -->
	<div class="breadcrumb-section">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></li>
							<li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Cart')); ?></li>
						</ol>
					</nav>
				</div>
				<div class="col-lg-6">
					<div class="page-title">
						<h1><?php echo e(__('Cart')); ?></h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /Page Breadcrumb/ -->
	
	<!-- Inner Section -->
	<section class="inner-section inner-section-bg">
		<div class="container">
			<?php if(session('shopping_cart')): ?>
			<div class="row">
				<div class="col-xl-12">
					<div class="table-responsive shopping-cart">
						<table class="table">
							<thead>
								<tr>
									<th><?php echo e(__('Image')); ?></th>
									<th><?php echo e(__('Product')); ?></th>
									<th><?php echo e(__('Sold By')); ?></th>
									<th class="text-center"><?php echo e(__('Unit')); ?></th>
									<th class="text-center"><?php echo e(__('Price')); ?></th>
									<th class="text-center"><?php echo e(__('Quantity')); ?></th>
									<th class="text-center"><?php echo e(__('Total')); ?></th>
									<th class="text-center"><?php echo e(__('Remove')); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = session('shopping_cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php
								
									$pro_price = $row['price'];
									$pro_qty = $row['qty'];
									
									$total_Price = $row['price']*$row['qty'];
									
									if($gtext['currency_position'] == 'left'){ 
										$price = $gtext['currency_icon'].NumberFormat($pro_price); 
									}else{
										$price = NumberFormat($pro_price).$gtext['currency_icon'];  
									}

									if($gtext['currency_position'] == 'left'){
										$totalPrice = $gtext['currency_icon'].NumberFormat($total_Price);
									}else{
										$totalPrice = NumberFormat($total_Price).$gtext['currency_icon'];
									}
									
								?>
								<tr id="row_delete_<?php echo e($row['id']); ?>">
									<td class="pro-image-w">
										<div class="pro-image">
											<a href="<?php echo e(route('frontend.product', [$row['id'], str_slug($row['name'])])); ?>">
												<img src="<?php echo e(asset('public/media/'.$row['thumbnail'])); ?>" alt="<?php echo e($row['name']); ?>">
											</a>
										</div>
									</td>
									<td class="pro-name-w" data-title="<?php echo e(__('Product')); ?>:">
										<span class="pro-name"><a href="<?php echo e(route('frontend.product', [$row['id'], str_slug($row['name'])])); ?>"><?php echo e($row['name']); ?></a></span>
									</td>
									<td class="pro-store-w" data-title="<?php echo e(__('Sold By')); ?>:">
										<a href="<?php echo e(route('frontend.stores', [$row['seller_id'], str_slug($row['store_name'])])); ?>"><?php echo e($row['store_name']); ?></a>
									</td>
									<td class="text-center pro-variation-w" data-title="<?php echo e(__('Unit')); ?>:">
										<span class="pro-variation"><?php echo e($row['unit']); ?></span>
									</td>
									<td class="text-center pro-price-w" data-title="<?php echo e(__('Price')); ?>:">
										<span class="pro-price"><span class="pro-price"><?php echo e($price); ?></span></span>
									</td>
									<td class="text-center pro-quantity-w" data-title="<?php echo e(__('Quantity')); ?>:">
										<div class="pro-quantity"><?php echo e($row['qty']); ?></div>
									</td>
									<td class="text-center pro-total-price-w" data-title="<?php echo e(__('Total')); ?>:">
										<span class="pro-total-price"><?php echo e($totalPrice); ?></span>
									</td>
									<td class="text-center pro-remove-w" data-title="Remove:">
										<a data-id="<?php echo e($row['id']); ?>" id="removetoviewcart_<?php echo e($row['id']); ?>" onclick="onRemoveToCart(<?php echo e($row['id']); ?>)" href="javascript:void(0);" class="pro-remove"><i class="bi bi-x-lg"></i></a>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-7"></div>
				<div class="col-lg-5 mt10">
					<div class="carttotals-card">
						<div class="carttotals-head"><?php echo e(__('Cart Total')); ?></div>
						<div class="carttotals-body">
							<table class="table">
								<tbody>
									<tr><td><span class="title"><?php echo e(__('Price Total')); ?></span><span class="price viewcart_price_total"></span></td></tr>
									<tr><td><span class="title"><?php echo e(__('Tax')); ?></span><span class="price viewcart_tax"></span></td></tr>
									<tr><td><span class="title"><?php echo e(__('Subtotal')); ?></span><span class="price viewcart_sub_total"></span></td></tr>
									<tr><td><span class="total"><?php echo e(__('Total')); ?></span><span class="total-price viewcart_total"></span></td></tr>
								</tbody>
							</table>
							<a class="btn theme-btn mt10" href="<?php echo e(route('frontend.checkout')); ?>"><?php echo e(__('Proceed To CheckOut')); ?></a>
						</div>
					</div>
				</div>
			</div>
			<?php else: ?>
			<div class="row">
				<div class="col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-4 offset-lg-4 col-xl-4 offset-xl-4 col-xxl-4 offset-xxl-4">
					<div class="empty_card">
						<div class="empty_img">
							<img src="<?php echo e(asset('public/frontend/images/empty.png')); ?>" />
						</div>
						<h3><?php echo e(__('Your cart is empty!')); ?></h3>
					</div>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</section>
	<!-- /Inner Section/ -->
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('public/frontend/pages/view_cart.js')); ?>"></script>
<?php $__env->stopPush(); ?>	
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/esheba/public_html/ecom1.e-sheba.com/resources/views/frontend/cart.blade.php ENDPATH**/ ?>