<ul class="tabs-nav">
	<li><a href="<?php echo e(route('backend.theme-options')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Logo')); ?></a></li>
	<li><a href="<?php echo e(route('backend.page-variation')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Page Variation')); ?></a></li>
	<li><a href="<?php echo e(route('backend.section-manage')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Section Manage')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-header')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Header')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-footer')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Footer')); ?></a></li>
	<li><a href="<?php echo e(route('backend.language-switcher')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Language Switcher')); ?></a></li>	
	<li><a href="<?php echo e(route('backend.theme-options-color')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Color')); ?></a></li>
	<li><a href="<?php echo e(route('backend.social-media')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Social Media')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-seo')); ?>"><i class="fa fa-cog"></i><?php echo e(__('SEO')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-facebook')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Facebook APP ID')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-facebook-pixel')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Facebook Pixel')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-twitter')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Twitter')); ?></a></li>
	<li><a href="<?php echo e(route('backend.google-analytics')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Google Analytics')); ?></a></li>
	<li><a href="<?php echo e(route('backend.google-tag-manager')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Google Tag Manager')); ?></a></li>
	<li><a href="<?php echo e(route('backend.theme-options-whatsapp')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Whatsapp')); ?></a></li>
	<li><a href="<?php echo e(route('backend.custom-css')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Custom CSS')); ?></a></li>
	<li><a href="<?php echo e(route('backend.custom-js')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Custom JS')); ?></a></li>
	<li><a href="<?php echo e(route('backend.cookie-consent')); ?>"><i class="fa fa-cog"></i><?php echo e(__('Cookie Consent')); ?></a></li>
</ul><?php /**PATH /home/esheba/public_html/ecom1.e-sheba.com/resources/views/backend/partials/theme_options_tabs_nav.blade.php ENDPATH**/ ?>