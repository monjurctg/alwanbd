<div class="table-responsive">
	<table class="table table-borderless table-theme" style="width:100%;">
		<thead>
			<tr>
				<th class="text-center" width="5%"><?php echo e(__('SL')); ?></th>
				<th class="text-left" width="35%"><?php echo e(__('Type')); ?></th>
				<th class="text-center" width="25%"><?php echo e(__('Width')); ?></th>
				<th class="text-center" width="25%"><?php echo e(__('Height')); ?></th>
				<th class="text-center" width="10%"><?php echo e(__('Action')); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($datalist)>0): ?>
			<?php $__currentLoopData = $datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td class="text-center"><?php echo e($key+1); ?></td>
				<td class="text-left"><?php echo e($row->media_type); ?></td>
				<td class="text-center"><?php echo e($row->media_width); ?></td>
				<td class="text-center"><?php echo e($row->media_height); ?></td>
				<td class="text-center">
					<div class="btn-group action-group">
						<a class="action-btn" href="javascript:void(0);" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
						<div class="dropdown-menu dropdown-menu-right">
							<a onclick="onEdit(<?php echo e($row->id); ?>)" class="dropdown-item" href="javascript:void(0);"><?php echo e(__('Edit')); ?></a>
						</div>
					</div>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<tr>
				<td class="text-center" colspan="5"><?php echo e(__('No data available')); ?></td>
			</tr>
			<?php endif; ?>
		</tbody>
	</table>
</div>
<div class="row mt-15">
	<div class="col-lg-12">
		<?php echo e($datalist->links()); ?>

	</div>
</div><?php /**PATH /home/elitdevs/ecommerce-15.elitdevs.com/resources/views/backend/partials/media_settings_table.blade.php ENDPATH**/ ?>