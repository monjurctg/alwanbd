

<?php $__env->startSection('title', __('Google Map')); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="main-body">
	<div class="container-fluid">
		<?php $vipc = vipc(); ?>
		<?php if($vipc['bkey'] == 0): ?> 
		<?php echo $__env->make('backend.partials.vipc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
		<div class="row mt-25">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header"><?php echo e(__('Settings')); ?></div>
					<div class="card-body tabs-area p-0">
						<?php echo $__env->make('backend.partials.settings_tabs_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="tabs-body">
							<!--Google Map Setting-->
							<div id="GoogleRecaptchaSetting">
								<form novalidate="" data-validate="parsley" id="GoogleMap_formId">
									<div class="row">
										<div class="col-lg-8">
											<div class="tw_checkbox checkbox_group">
												<input id="is_googlemap" name="is_googlemap" type="checkbox" <?php echo e($datalist['is_googlemap'] == 1 ? 'checked' : ''); ?>>
												<label for="is_googlemap"><?php echo e(__('Enable/Disable')); ?></label>
												<span></span>
											</div>
											<div class="form-group">
												<label for="googlemap_apikey"><?php echo e(__('Site Key')); ?><span class="red">*</span></label>
												<input type="text" name="googlemap_apikey" id="googlemap_apikey" class="form-control parsley-validated" data-required="true" value="<?php echo e($datalist['googlemap_apikey']); ?>">
											</div>
										</div>
										<div class="col-lg-4"></div>
									</div>
									<div class="row tabs-footer mt-15">
										<div class="col-lg-12">
											<a id="map_submit_form" href="javascript:void(0);" class="btn blue-btn"><?php echo e(__('Save')); ?></a>
										</div>
									</div>
								</form>
							</div>
							<!--/Google Map Setting-->
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- /main Section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('public/backend/pages/google-map.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elitdevs/ecommerce-15.elitdevs.com/resources/views/backend/google-map.blade.php ENDPATH**/ ?>