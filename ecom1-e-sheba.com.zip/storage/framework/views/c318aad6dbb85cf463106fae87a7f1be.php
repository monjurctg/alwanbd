

<?php $__env->startSection('title', __('Footer')); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="main-body">
	<div class="container-fluid">
		<?php $vipc = vipc(); ?>
		<?php if($vipc['bkey'] == 0): ?> 
		<?php echo $__env->make('backend.partials.vipc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
		<div class="row mt-25">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-lg-12">
								<?php echo e(__('Footer')); ?>

							</div>
						</div>
					</div>
					<div class="card-body tabs-area p-0">
						<?php echo $__env->make('backend.partials.theme_options_tabs_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="tabs-body">
							<!--Data Entry Form-->
							<form novalidate="" data-validate="parsley" id="DataEntry_formId">
								<div class="divider_heading"><?php echo e(__('About Us')); ?></div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label for="about_logo"><?php echo e(__('Logo')); ?></label>
											<div class="tp-upload-field">
												<input type="text" value="<?php echo e($datalist['payment_gateway_icon']); ?>" name="about_logo" id="about_logo" class="form-control" readonly>
												<a id="on_about_logo" href="javascript:void(0);" class="tp-upload-btn"><i class="fa fa-window-restore"></i><?php echo e(__('Browse')); ?></a>
											</div>
											<div id="remove_about_logo" class="select-image dnone">
												<div class="inner-image" id="view_about_logo">
												</div>
												<a onClick="onMediaImageRemove('about_logo')" class="media-image-remove" href="javascript:void(0);"><i class="fa fa-remove"></i></a>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="about_desc"><?php echo e(__('About Us')); ?></label>
											<textarea name="about_desc" id="about_desc" class="form-control" rows="2"><?php echo e($datalist['about_desc']); ?></textarea>
										</div>
									</div>
								</div>

								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label for="is_publish_about"><?php echo e(__('Status')); ?></label>
											<select name="is_publish_about" id="is_publish_about" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php echo e($row->id == $datalist['is_publish_about'] ? "selected=selected" : ''); ?> value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-8"></div>
								</div>
							
							
								<div class="divider_heading"><?php echo e(__('Contact Us')); ?></div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="address"><?php echo e(__('Address')); ?></label>
											<input value="<?php echo e($datalist['address']); ?>" type="text" name="address" id="address" class="form-control">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="email"><?php echo e(__('Email')); ?></label>
											<input value="<?php echo e($datalist['email']); ?>" type="text" name="email" id="email" class="form-control">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="phone"><?php echo e(__('Phone')); ?></label>
											<input value="<?php echo e($datalist['phone']); ?>" type="text" name="phone" id="phone" class="form-control">
										</div>
									</div>
								</div>

								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label for="is_publish_contact"><?php echo e(__('Status')); ?></label>
											<select name="is_publish_contact" id="is_publish_contact" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php echo e($row->id == $datalist['is_publish_contact'] ? "selected=selected" : ''); ?> value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-8"></div>
								</div>
								
								<div class="divider_heading"><?php echo e(__('Copyright')); ?></div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="copyright"><?php echo e(__('Copyright')); ?></label>
											<input value="<?php echo e($datalist['copyright']); ?>" type="text" name="copyright" id="copyright" class="form-control">
										</div>
									</div>
								</div>
								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label for="is_publish_copyright"><?php echo e(__('Status')); ?></label>
											<select name="is_publish_copyright" id="is_publish_copyright" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php echo e($row->id == $datalist['is_publish_copyright'] ? "selected=selected" : ''); ?> value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-8"></div>
								</div>
								
								<div class="divider_heading"><?php echo e(__('Payment Gateway Icon')); ?></div>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label for="payment_gateway_icon"><?php echo e(__('Payment Gateway Icon')); ?></label>
											<div class="tp-upload-field">
												<input value="<?php echo e($datalist['payment_gateway_icon']); ?>" type="text" name="payment_gateway_icon" id="payment_gateway_icon" class="form-control" readonly>
												<a id="on_payment_gateway_icon" href="javascript:void(0);" class="tp-upload-btn"><i class="fa fa-window-restore"></i><?php echo e(__('Browse')); ?></a>
											</div>
											<em>Recommended image size height:22px.</em>
											<div id="remove_payment_gateway_icon" class="select-image dnone">
												<div class="inner-image" id="view_payment_gateway_icon">
												</div>
												<a onClick="onMediaImageRemove('payment_gateway_icon')" class="media-image-remove" href="javascript:void(0);"><i class="fa fa-remove"></i></a>
											</div>
										</div>
									</div>
								</div>
								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label for="is_publish_payment"><?php echo e(__('Status')); ?></label>
											<select name="is_publish_payment" id="is_publish_payment" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php echo e($row->id == $datalist['is_publish_payment'] ? "selected=selected" : ''); ?> value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-8"></div>
								</div>
								<div class="row tabs-footer mt-15">
									<div class="col-lg-12">
										<a id="submit-form" href="javascript:void(0);" class="btn blue-btn"><?php echo e(__('Save')); ?></a>
									</div>
								</div>
							</form>
							<!--/Data Entry Form/-->
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- /main Section -->

<!--Global Media-->
<?php echo $__env->make('backend.partials.global_media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/Global Media/-->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- css/js -->
<script type="text/javascript">
var media_type = 'Thumbnail';

var about_logo = "<?php echo e($datalist['about_logo']); ?>";
if(about_logo == ''){
	$("#remove_about_logo").hide();
	$("#about_logo").html('');
}
if(about_logo != ''){
	$("#remove_about_logo").show();
	$("#view_about_logo").html('<img src="'+public_path+'/media/'+about_logo+'">');
}

var payment_gateway_icon = "<?php echo e($datalist['payment_gateway_icon']); ?>";
if(payment_gateway_icon == ''){
	$("#remove_payment_gateway_icon").hide();
	$("#payment_gateway_icon").html('');
}
if(payment_gateway_icon != ''){
	$("#remove_payment_gateway_icon").show();
	$("#view_payment_gateway_icon").html('<img src="'+public_path+'/media/'+payment_gateway_icon+'">');
}
</script>
<script src="<?php echo e(asset('public/backend/pages/theme_option_footer.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/pages/global-media.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\resources\views/backend/theme-options-footer.blade.php ENDPATH**/ ?>