
<div class="sidebar">

	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Categories')); ?></div>
		<div class="widget-body">
			<ul class="widget-list">
				<?php $CategoryListForFilter = CategoryListForFilter(); ?>
				<?php $__currentLoopData = $CategoryListForFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="icon">
						<a href="<?php echo e(route('frontend.product-category', [$row->id, $row->slug])); ?>">
							<img src="<?php echo e(asset('public/media/'.$row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" />
						</a>
					</div>
					<div class="desc">
						<a href="<?php echo e(route('frontend.product-category', [$row->id, $row->slug])); ?>"><?php echo e($row->name); ?></a>
					</div>
					<div class="count"><?php echo e($row->TotalProduct); ?></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
	
	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Filter by Price')); ?></div>
		<div class="widget-body">
			<div class="slider-range">
				<div id="slider-range"></div>
				<div class="price-range">
					<div class="price-label"><?php echo e(__('Price Range')); ?>:</div>
					<div class="price" id="amount"></div>
				</div>
				<input id="filter_min_price" type="hidden" value="0" />
				<input id="filter_max_price" type="hidden" />
				<a id="FilterByPrice" href="javascript:void(0);" class="btn theme-btn filter-btn"><i class="bi bi-funnel"></i> <?php echo e(__('Filter')); ?></a>
			</div>
		</div>
	</div>
	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Brands')); ?></div>
		<div class="widget-body">
			<ul class="widget-list">
				<?php $BrandListForFilter = BrandListForFilter(); ?>
				<?php $__currentLoopData = $BrandListForFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="icon">
						<a href="<?php echo e(route('frontend.brand', [$row->id, str_slug($row->name)])); ?>">
							<img src="<?php echo e(asset('public/media/'.$row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" />
						</a>
					</div>
					<div class="desc">
						<a href="<?php echo e(route('frontend.brand', [$row->id, str_slug($row->name)])); ?>"><?php echo e($row->name); ?></a>
					</div>
					<div class="count"><?php echo e($row->TotalProduct); ?></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>
<?php /**PATH /home/elitede1/ecommerce15.elitedesign.com.bd/resources/views/frontend/partials/sidebar.blade.php ENDPATH**/ ?>