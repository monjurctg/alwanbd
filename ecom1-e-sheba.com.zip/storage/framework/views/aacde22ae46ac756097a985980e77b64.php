

<?php $__env->startSection('title', __('Menu')); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="main-body">
	<div class="container-fluid">
		<?php $vipc = vipc(); ?>
		<?php if($vipc['bkey'] == 0): ?> 
		<?php echo $__env->make('backend.partials.vipc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
		<div class="row mt-25">
			<div class="col-lg-3">
				<div class="card">
					<div class="card-body">
						<form novalidate="" data-validate="parsley" id="DataEntry_formId">
							<div class="form-group">
								<label for="menu_name"><?php echo e(__('Menu Name')); ?><span class="red">*</span></label>
								<input type="text" name="menu_name" id="menu_name" class="form-control parsley-validated" data-required="true">
							</div>
							<div class="form-group">
								<label for="menu_position"><?php echo e(__('Menu Position')); ?><span class="red">*</span></label>
								<select name="menu_position" id="menu_position" class="chosen-select form-control">
									<option value="header">Header Menu</option>
									<option value="footer">Footer Menu</option>
								</select>
							</div>
							<div class="form-group">
								<label for="lan"><?php echo e(__('Language')); ?><span class="red">*</span></label>
								<select name="lan" id="lan" class="chosen-select form-control">
								<?php $__currentLoopData = $languagelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($row->language_code); ?>">
										<?php echo e($row->language_name); ?>

									</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group">
								<label for="status_id"><?php echo e(__('Menu Status')); ?><span class="red">*</span></label>
								<select name="status_id" id="status_id" class="chosen-select form-control">
								<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($row->id); ?>">
										<?php echo e($row->status); ?>

									</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<input class="dnone" type="text" name="RecordId" id="RecordId">
							
							<a id="submit-form" href="javascript:void(0);" class="btn blue-btn mr-10"><?php echo e(__('Save')); ?></a>
						</form>
					</div>
				</div>
			</div>
			<div class="col-lg-9">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-lg-4">
								<div class="form-group bulk-box">
									<select id="bulk-action" class="form-control">
										<option value=""><?php echo e(__('Select Action')); ?></option>
										<option value="publish"><?php echo e(__('Publish')); ?></option>
										<option value="draft"><?php echo e(__('Draft')); ?></option>
										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
									</select>
									<button type="submit" onClick="onBulkAction()" class="btn bulk-btn"><?php echo e(__('Apply')); ?></button>
								</div>
							</div>
							<div class="col-lg-3"></div>
							<div class="col-lg-5">
								<div class="form-group search-box">
									<input id="search" name="search" type="text" class="form-control" placeholder="<?php echo e(__('Search')); ?>...">
									<button type="submit" onClick="onMenuSearch()" class="btn search-btn"><?php echo e(__('Search')); ?></button>
								</div>
							</div>
						</div>
						<div id="menu_datalist">
							<?php echo $__env->make('backend.partials.menu_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- /main Section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- css/js -->
<script type="text/javascript">
var TEXT = [];
	TEXT['Do you really want to edit this record'] = "<?php echo e(__('Do you really want to edit this record')); ?>";
	TEXT['Do you really want to delete this record'] = "<?php echo e(__('Do you really want to delete this record')); ?>";
	TEXT['Do you really want to publish this records'] = "<?php echo e(__('Do you really want to publish this records')); ?>";
	TEXT['Do you really want to draft this records'] = "<?php echo e(__('Do you really want to draft this records')); ?>";
	TEXT['Do you really want to delete this records'] = "<?php echo e(__('Do you really want to delete this records')); ?>";
	TEXT['Please select action'] = "<?php echo e(__('Please select action')); ?>";
	TEXT['Please select record'] = "<?php echo e(__('Please select record')); ?>";
</script>
<script src="<?php echo e(asset('public/backend/pages/menu.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elitdevs/ecommerce-15.elitdevs.com/resources/views/backend/menu.blade.php ENDPATH**/ ?>