<?php $__env->startSection('title', __('Reset Password')); ?>

<?php $gtext = gtext(); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="loginsignup-area">
				<div class="loginsignup text-center">
					<div class="logo">
						<a href="<?php echo e(url('/login')); ?>">
							<img src="<?php echo e($gtext['back_logo'] ? asset('public/media/'.$gtext['back_logo']) : asset('public/backend/images/backend-logo.png')); ?>" alt="logo">
						</a>
					</div>
					<p><?php echo e(__('Enter your email address below and we will send you a link to reset your password')); ?></p>
					<?php if(Session::has('success')): ?>
					<div class="alert alert-success">
						<?php echo e(Session::get('success')); ?>

					</div>
					<?php endif; ?>
					<?php if(Session::has('fail')): ?>
					<div class="alert alert-danger">
						<?php echo e(Session::get('fail')); ?>

					</div>
					<?php endif; ?>
					<form class="text-left" id="login_form" method="POST" action="<?php echo e(route('frontend.resetPassword')); ?>">
						<?php echo csrf_field(); ?>
						
						<div class="form-group">
							<input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="<?php echo e(__('Email Address')); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email">
							<?php if($errors->has('email')): ?>
							<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
						</div>

						<?php if($gtext['is_recaptcha'] == 1): ?>
						<div class="form-group">
							<div class="g-recaptcha" data-sitekey="<?php echo e($gtext['sitekey']); ?>"></div>
							<?php if($errors->has('g-recaptcha-response')): ?>
							<span class="text-danger"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
							<?php endif; ?>
						</div>
						<?php endif; ?>
						<input type="submit" class="btn login-btn" value="<?php echo e(__('Send Password Reset Link')); ?>">
					</form>
					<h3><a href="<?php echo e(url('/login')); ?>"><?php echo e(__('Back to login')); ?></a></h3>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /main Section -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if($gtext['is_recaptcha'] == 1): ?>
<script src='https://www.google.com/recaptcha/api.js' async defer></script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elitdevs/ecommerce-15.elitdevs.com/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>