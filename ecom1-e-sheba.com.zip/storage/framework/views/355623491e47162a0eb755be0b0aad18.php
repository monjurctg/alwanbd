
<div class="row mt-15">
	<div class="col-md-12">
		<div class="alert alert-danger" role="alert">
			Please provide valid purchase code. <a class="aclick text-bold" href="<?php echo e(route('backend.theme-register')); ?>">Click Here</a>
		</div>
	</div>
</div><?php /**PATH F:\xampp\htdocs\resources\views/backend/partials/vipc.blade.php ENDPATH**/ ?>