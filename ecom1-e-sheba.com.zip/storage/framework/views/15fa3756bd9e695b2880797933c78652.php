
<div class="sidebar">

	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Blog Categories')); ?></div>
		<div class="widget-body">
			<ul class="widget-list">
				<?php $BlogCategoryListForFilter = BlogCategoryListForFilter(); ?>
				<?php $__currentLoopData = $BlogCategoryListForFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="desc">
						<a href="<?php echo e(route('frontend.blog-category', [$row->id, $row->slug])); ?>"><?php echo e($row->name); ?></a>
					</div>
					<div class="count"><?php echo e($row->TotalProduct); ?></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>

	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Categories')); ?></div>
		<div class="widget-body">
			<ul class="widget-list">
				<?php $CategoryListForFilter = CategoryListForFilter(); ?>
				<?php $__currentLoopData = $CategoryListForFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="icon">
						<a href="<?php echo e(route('frontend.product-category', [$row->id, $row->slug])); ?>">
							<img src="<?php echo e(asset('public/media/'.$row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" />
						</a>
					</div>
					<div class="desc">
						<a href="<?php echo e(route('frontend.product-category', [$row->id, $row->slug])); ?>"><?php echo e($row->name); ?></a>
					</div>
					<div class="count"><?php echo e($row->TotalProduct); ?></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
	
	<div class="widget-card">
		<div class="widget-title"><?php echo e(__('Brands')); ?></div>
		<div class="widget-body">
			<ul class="widget-list">
				<?php $BrandListForFilter = BrandListForFilter(); ?>
				<?php $__currentLoopData = $BrandListForFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="icon">
						<a href="<?php echo e(route('frontend.brand', [$row->id, str_slug($row->name)])); ?>">
							<img src="<?php echo e(asset('public/media/'.$row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" />
						</a>
					</div>
					<div class="desc">
						<a href="<?php echo e(route('frontend.brand', [$row->id, str_slug($row->name)])); ?>"><?php echo e($row->name); ?></a>
					</div>
					<div class="count"><?php echo e($row->TotalProduct); ?></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>
<?php /**PATH /home/elitdevs/ecommerce-15.elitdevs.com/resources/views/frontend/partials/blog_sidebar.blade.php ENDPATH**/ ?>