

<?php $__env->startSection('title', __('SEO')); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="main-body">
	<div class="container-fluid">
		<?php $vipc = vipc(); ?>
		<?php if($vipc['bkey'] == 0): ?> 
		<?php echo $__env->make('backend.partials.vipc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
		<div class="row mt-25">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-lg-12">
								<?php echo e(__('SEO')); ?>

							</div>
						</div>
					</div>
					<div class="card-body tabs-area p-0">
						<?php echo $__env->make('backend.partials.theme_options_tabs_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="tabs-body">
							<!--Data Entry Form-->
							<form novalidate="" data-validate="parsley" id="DataEntry_formId">
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="og_title"><?php echo e(__('SEO Title')); ?></label>
											<input value="<?php echo e($datalist['og_title']); ?>" type="text" name="og_title" id="og_title" class="form-control">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="og_keywords"><?php echo e(__('SEO Keywords')); ?></label>
											<input value="<?php echo e($datalist['og_keywords']); ?>" type="text" name="og_keywords" id="og_keywords" class="form-control">
										</div>
									</div>
								</div>
								<div class="row">	
									<div class="col-md-12">
										<div class="form-group">
											<label for="og_description"><?php echo e(__('SEO Description')); ?></label>
											<textarea name="og_description" id="og_description" class="form-control" rows="2"><?php echo e($datalist['og_description']); ?></textarea>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<label for="og_image"><?php echo e(__('Open Graph Image')); ?></label>
											<div class="tp-upload-field">
												<input value="<?php echo e($datalist['og_image']); ?>" type="text" name="og_image" id="og_image" class="form-control" readonly>
												<a onClick="onGlobalMediaModalView()" href="javascript:void(0);" class="tp-upload-btn"><i class="fa fa-window-restore"></i><?php echo e(__('Browse')); ?></a>
											</div>
											<em>e.g. Facebook share image. Recommended image size width: 600px and height: 315px.</em>
											<div id="remove_og_image" class="select-image dnone">
												<div class="inner-image" id="view_og_image">
												</div>
												<a onClick="onMediaImageRemove('og_image')" class="media-image-remove" href="javascript:void(0);"><i class="fa fa-remove"></i></a>
											</div>
										</div>
									</div>
								</div>
								<div class="row">	
									<div class="col-md-4">
										<div class="form-group">
											<label for="is_publish"><?php echo e(__('Status')); ?></label>
											<select name="is_publish" id="is_publish" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php echo e($row->id == $datalist['is_publish'] ? "selected=selected" : ''); ?> value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-8"></div>
								</div>
								<div class="row tabs-footer mt-15">
									<div class="col-lg-12">
										<a id="submit-form" href="javascript:void(0);" class="btn blue-btn"><?php echo e(__('Save')); ?></a>
									</div>
								</div>
							</form>
							<!--/Data Entry Form/-->
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- /main Section -->

<!--Global Media-->
<?php echo $__env->make('backend.partials.global_media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--/Global Media/-->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- css/js -->
<script type="text/javascript">
var media_type = 'SEO_Image';

var og_image = "<?php echo e($datalist['og_image']); ?>";
if(og_image == ''){
	$("#remove_og_image").hide();
	$("#og_image").html('');
}
if(og_image != ''){
	$("#remove_og_image").show();
	$("#view_og_image").html('<img src="'+public_path+'/media/'+og_image+'">');
}
</script>
<script src="<?php echo e(asset('public/backend/pages/theme_option_seo.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/pages/global-media.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\resources\views/backend/theme-options-seo.blade.php ENDPATH**/ ?>