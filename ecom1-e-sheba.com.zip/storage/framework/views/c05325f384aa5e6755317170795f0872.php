

<?php $__env->startSection('title', __('Contact')); ?>

<?php $__env->startSection('content'); ?>
<!-- main Section -->
<div class="main-body">
	<div class="container-fluid">
		<?php $vipc = vipc(); ?>
		<?php if($vipc['bkey'] == 0): ?> 
		<?php echo $__env->make('backend.partials.vipc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php else: ?>
		<div class="row mt-25">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-lg-6">
								<span><?php echo e(__('Contact')); ?></span>
							</div>
							<div class="col-lg-6">
								<div class="float-right">
									<a onClick="onFormPanel()" href="javascript:void(0);" class="btn blue-btn btn-form float-right"><i class="fa fa-plus"></i> <?php echo e(__('Add New')); ?></a>
									<a onClick="onListPanel()" href="javascript:void(0);" class="btn warning-btn btn-list float-right dnone"><i class="fa fa-reply"></i> <?php echo e(__('Back to List')); ?></a>
								</div>
							</div>
						</div>
					</div>
					<!--Data grid-->
					<div id="list-panel" class="card-body">
						<div class="row">
							<div class="col-lg-9 mb-10">
								<div class="group-button">
									<button type="button" onClick="onDataViewByStatus(0)" id="viewstatus_0" class="btn btn-theme viewstatus active"><?php echo e(__('All')); ?> (<?php echo e($AllCount); ?>)</button>
									<button type="button" onClick="onDataViewByStatus(1)" id="viewstatus_1" class="btn btn-theme viewstatus"><?php echo e(__('Published')); ?> (<?php echo e($PublishedCount); ?>)</button>
									<button type="button" onClick="onDataViewByStatus(2)" id="viewstatus_2" class="btn btn-theme viewstatus"><?php echo e(__('Draft')); ?> (<?php echo e($DraftCount); ?>)</button>
								</div>
								<input type="hidden" id="ViewByPostStatus" value="0"/>
							</div>
							<div class="col-lg-3 mb-10">
								<div class="form-group">
									<select name="language_code" id="language_code" class="chosen-select form-control">
										<option value="0" selected="selected"><?php echo e(__('All Language')); ?></option>
										<?php $__currentLoopData = $languageslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($row->language_code); ?>">
												<?php echo e($row->language_name); ?>

											</option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-4">
								<div class="form-group bulk-box">
									<select id="bulk-action" class="form-control">
										<option value=""><?php echo e(__('Select Action')); ?></option>
										<option value="publish"><?php echo e(__('Publish')); ?></option>
										<option value="draft"><?php echo e(__('Draft')); ?></option>
										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
									</select>
									<button type="submit" onClick="onBulkAction()" class="btn bulk-btn"><?php echo e(__('Apply')); ?></button>
								</div>
							</div>
							<div class="col-lg-3"></div>
							<div class="col-lg-5">
								<div class="form-group search-box">
									<input id="search" name="search" type="text" class="form-control" placeholder="<?php echo e(__('Search')); ?>...">
									<button type="submit" onClick="onSearch()" class="btn search-btn"><?php echo e(__('Search')); ?></button>
								</div>
							</div>
						</div>
						<div id="page_datalist">
							<?php echo $__env->make('backend.partials.contact_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
					<!--/Data grid/-->
					
					<!--Data Entry Form-->
					<div id="form-panel" class="card-body dnone">
						<form novalidate="" data-validate="parsley" id="DataEntry_formId">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="title"><?php echo e(__('Title')); ?><span class="red">*</span></label>
										<input type="text" name="title" id="title" class="form-control parsley-validated" data-required="true">
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label for="lan"><?php echo e(__('Language')); ?><span class="red">*</span></label>
										<select name="lan" id="lan" class="chosen-select form-control">
											<?php $__currentLoopData = $languageslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($row->language_code); ?>">
													<?php echo e($row->language_name); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label for="is_publish"><?php echo e(__('Status')); ?><span class="red">*</span></label>
										<select name="is_publish" id="is_publish" class="chosen-select form-control">
											<?php $__currentLoopData = $statuslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($row->id); ?>">
													<?php echo e($row->status); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
							</div>
							<div class="divider_heading"><?php echo e(__('Contact Info')); ?></div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="email"><?php echo e(__('Email')); ?><span class="red">*</span></label>
										<input type="text" name="email" id="email" class="form-control parsley-validated" data-required="true">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="phone"><?php echo e(__('Phone')); ?><span class="red">*</span></label>
										<input type="text" name="phone" id="phone" class="form-control parsley-validated" data-required="true">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label for="address"><?php echo e(__('Address')); ?><span class="red">*</span></label>
										<textarea name="address" id="address" class="form-control parsley-validated" data-required="true" rows="2"></textarea>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label for="short_desc"><?php echo e(__('Short Description')); ?></label>
										<textarea name="short_desc" id="short_desc" class="form-control" rows="2"></textarea>
									</div>
								</div>
							</div>

							<div class="divider_heading"><?php echo e(__('Google Map')); ?></div>
							<div class="row">
								<div class="col-md-3">
									<div class="form-group">
										<label for="latitude"><?php echo e(__('Latitude')); ?></label>
										<input type="text" name="latitude" id="latitude" class="form-control">
									</div>
								</div>
								<div class="col-md-3">
									<div class="form-group">
										<label for="longitude"><?php echo e(__('Longitude')); ?></label>
										<input type="text" name="longitude" id="longitude" class="form-control">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label for="zoom"><?php echo e(__('Zoom')); ?></label>
										<input type="text" name="zoom" id="zoom" class="form-control">
									</div>
								</div>
								<div class="col-md-4">
									<p class="mb0">If you are not yet added Google Map API key. <strong><a href="<?php echo e(route('backend.google-map')); ?>">Click Here</a></strong></p>
									<div class="tw_checkbox checkbox_group">
										<input id="is_google_map" name="is_google_map" type="checkbox">
										<label for="is_google_map"><?php echo e(__('Enable/Disable')); ?></label>
										<span></span>
									</div>
								</div>
							</div>
							
							<div class="divider_heading"><?php echo e(__('Contact Form')); ?></div>
							
							<div id="FormElementId"></div>

							<div class="row">
								<div class="col-lg-12">
									<div class="form-builder">
										<a onclick="onAddField()" class="add_field_btn" href="javascript:void(0);" title="<?php echo e(__('Add Field')); ?>"><i class="fa fa-plus"></i></a>
									</div>
								</div>
							</div>
							
							<div class="row mt-25" id="mailSubjectHideShow">
								<div class="col-md-3">
									<div class="form-group">
										<label for="mail_subject"><?php echo e(__('Select Mail Subject Field')); ?><span class="red">*</span></label>
										<select name="mail_subject" id="mail_subject" class="chosen-select form-control">
										</select>
									</div>
								</div>
								<div class="col-md-9"></div>
							</div>
							
							<div class="row">
								<div class="col-md-12">
									<p class="mt-15 mb0"><strong><?php echo e(__('Google reCAPTCHA')); ?></strong> (If you are not yet added Google reCAPTCHA key. <strong><a href="<?php echo e(route('backend.google-recaptcha')); ?>">Click Here</a></strong>)</p>
									<div class="tw_checkbox checkbox_group">
										<input id="is_recaptcha" name="is_recaptcha" type="checkbox">
										<label for="is_recaptcha"><?php echo e(__('Enable/Disable')); ?></label>
										<span></span>
									</div>
								</div>
							</div>

							<input type="text" name="RecordId" id="RecordId" class="dnone">
							<div class="row tabs-footer mt-15">
								<div class="col-lg-12">
									<a id="submit-form" href="javascript:void(0);" class="btn blue-btn mr-10"><?php echo e(__('Save')); ?></a>
								</div>
							</div>
						</form>
					</div>
					<!--/Data Entry Form/-->
				</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<!-- /main Section -->

<div class="modal page-builder-modal" id="element_forms_modal">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header tp-modal-header">
				<h5 class="modal-title"><?php echo e(__('Add Field')); ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form novalidate="" data-validate="parsley" id="Element_DataEntry_formId">
				<div class="modal-body tp-modal-body">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="field_label"><?php echo e(__('Label')); ?><span class="red">*</span></label>
									<input type="text" name="field_label" id="field_label" class="form-control">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="field_type"><?php echo e(__('Type')); ?><span class="red">*</span></label>
									<select name="field_type" id="field_type" class="chosen-select form-control">
										<option value="text">Text</option>
										<option value="email">Email</option>
										<option value="textarea">Textarea</option>
										<option value="dropdown">Dropdown</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="field_name"><?php echo e(__('Name')); ?><span class="red">*</span></label>
									<input type="text" name="field_name" id="field_name" class="form-control">
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="field_placeholder"><?php echo e(__('Placeholder')); ?></label>
									<input type="text" name="field_placeholder" id="field_placeholder" class="form-control">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="is_label"><?php echo e(__('Label Show/Hide')); ?><span class="red">*</span></label>
									<select name="is_label" id="is_label" class="chosen-select form-control">
										<option value="no">No</option>
										<option value="yes">Yes</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="field_mandatory"><?php echo e(__('Mandatory')); ?><span class="red">*</span></label>
									<select name="field_mandatory" id="field_mandatory" class="chosen-select form-control">
										<option value="no">No</option>
										<option value="yes">Yes</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row dnone" id="dropdown_values_id">
							<div class="col-md-12">
								<div class="form-group">
									<label for="dropdown_values"><?php echo e(__('Dropdown Values')); ?></label>
									<textarea name="dropdown_values" id="dropdown_values" class="form-control" rows="2" placeholder="value1|value2|value3"></textarea>
									<span>Example dropdown value (value1|value2|value3). separator ( | )</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<a onclick="onSaveChanges()" href="javascript:void(0);" class="btn blue-btn"><?php echo e(__('Save changes')); ?></a>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- css/js -->
<script type="text/javascript">
var TEXT = [];
	TEXT['Do you really want to edit this record'] = "<?php echo e(__('Do you really want to edit this record')); ?>";
	TEXT['Do you really want to delete this record'] = "<?php echo e(__('Do you really want to delete this record')); ?>";
	TEXT['Do you really want to publish this records'] = "<?php echo e(__('Do you really want to publish this records')); ?>";
	TEXT['Do you really want to draft this records'] = "<?php echo e(__('Do you really want to draft this records')); ?>";
	TEXT['Do you really want to delete this records'] = "<?php echo e(__('Do you really want to delete this records')); ?>";
	TEXT['Please select action'] = "<?php echo e(__('Please select action')); ?>";
	TEXT['Please select record'] = "<?php echo e(__('Please select record')); ?>";
	TEXT['Please fill up all mandatory fields'] = "<?php echo e(__('Please fill up all mandatory fields')); ?>";
</script>
<script src="<?php echo e(asset('public/backend/pages/contacts_page.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/esheba/public_html/ecom1.e-sheba.com/resources/views/backend/contact.blade.php ENDPATH**/ ?>