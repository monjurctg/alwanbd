<main class="main <?php echo e($PageVariation['home_variation']); ?>">
<!-- Home Slider -->
	<?php if($section1->is_publish == 1): ?>
	<section class="slider-section">
		<div class="slider-screen h1-height" style="background-image: url(<?php echo e($section1->image ? asset('public/media/'.$section1->image) : ''); ?>);">
			<div class="home-slider owl-carousel">
				<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $aRow = json_decode($row->desc); ?>
				<!-- Slider Item -->
				<div class="single-slider">
					<div class="container">
						<div class="row">
							<div class="order-1 col-sm-12 order-sm-1 col-md-6 order-md-0 col-lg-5 order-lg-0">
								<div class="slider-content">
									<h1><?php echo e($row->title); ?></h1>
									<?php if($aRow->sub_title != ''): ?>
									<p class="relative"><?php echo e($aRow->sub_title); ?></p>
									<?php endif; ?>
									
									<?php if($aRow->button_text != ''): ?>
									<a href="<?php echo e($row->url); ?>" class="btn theme-btn" <?php echo e($aRow->target =='' ? '' : "target=".$aRow->target); ?>><?php echo e($aRow->button_text); ?></a>
									<?php endif; ?>
									
									<?php if($aRow->layer_image_1 != ''): ?>
									<div class="h1-layer2 layer-bounce2">
										<img src="<?php echo e(asset('public/media/'.$aRow->layer_image_1)); ?>" alt="<?php echo e($row->title); ?>" />
									</div>
									<?php endif; ?>
								</div>
							</div>
							<div class="order-0 col-sm-12 order-sm-0 col-md-6 order-md-1 col-lg-7 order-lg-1">
								<?php if($aRow->layer_image_2 != ''): ?>
								<div class="h1-layer3 layer-bounce3">
									<img src="<?php echo e(asset('public/media/'.$aRow->layer_image_2)); ?>" alt="<?php echo e($row->title); ?>" />
								</div>
								<?php endif; ?>
								<div class="h1-layer1 layer-bounce1">
									<img src="<?php echo e(asset('public/media/'.$row->image)); ?>" alt="<?php echo e($row->title); ?>" />
								</div>
								<?php if($aRow->layer_image_3 != ''): ?>
								<div class="h1-layer4 layer-bounce4">
									<img src="<?php echo e(asset('public/media/'.$aRow->layer_image_3)); ?>" alt="<?php echo e($row->title); ?>" />
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<!-- /Slider Item/ -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Home Slider/ -->
	
	<!-- Featured Categories -->
	<?php if($section2->is_publish == 1): ?>
	<section class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-heading">
						<?php if($section2->desc !=''): ?>
						<h5><?php echo e($section2->desc); ?></h5>
						<?php endif; ?>
						
						<?php if($section2->title !=''): ?>
						<h2><?php echo e($section2->title); ?></h2>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row owl-carousel caro-common featured-categories">
				<?php $__currentLoopData = $pro_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-12">
					<div class="featured-card">
						<div class="featured-image">
							<img src="<?php echo e(asset('public/media/'.$row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" />
						</div>
						<div class="featured-title">
							<a href="<?php echo e(route('frontend.product-category', [$row->id, $row->slug])); ?>"><?php echo e($row->name); ?></a>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Featured Categories/ -->
		
	<!-- Popular Products -->
	<?php if($section3->is_publish == 1): ?>
	<section class="section product-section">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section-heading">
						<?php if($section3->desc !=''): ?>
						<h5><?php echo e($section3->desc); ?></h5>
						<?php endif; ?>
						
						<?php if($section3->title !=''): ?>
						<h2><?php echo e($section3->title); ?></h2>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row owl-carousel caro-common category-carousel">
			
				<?php $__currentLoopData = $popular_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-12">
					<div class="item-card">
						<div class="item-image">
							<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
								<?php 
									$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
								?>
							<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
							<?php endif; ?>
							<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
								<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
							</a>
						</div>
						<div class="item-title">
							<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
						</div>
						<div class="rating-wrap">
							<div class="stars-outer">
								<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
							</div>
							<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
						</div>
						<div class="item-sold">
							<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
						</div>
						<div class="item-pric-card">
							<?php if($row->sale_price != ''): ?>
								<?php if($gtext['currency_position'] == 'left'): ?>
								<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
								<?php else: ?>
								<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
								<?php endif; ?>
							<?php endif; ?>
							<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
								<?php if($gtext['currency_position'] == 'left'): ?>
								<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
								<?php else: ?>
								<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
								<?php endif; ?>
							<?php endif; ?>
						</div>
						<div class="item-card-bottom">
							<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
							<ul class="item-cart-list">
								<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
								<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Popular Products/ -->
	
	<!-- Offer Section -->
	<?php if($section4->is_publish == 1): ?>
	<?php if(count($offer_ad_position1)>0): ?>
	<section class="section offer-section" style="background-image: url(<?php echo e($section4->image ? asset('public/media/'.$section4->image) : ''); ?>);">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-heading">
						<?php if($section4->desc !=''): ?>
						<h5><?php echo e($section4->desc); ?></h5>
						<?php endif; ?>
						
						<?php if($section4->title !=''): ?>
						<h2><?php echo e($section4->title); ?></h2>
						<?php endif; ?>
					</div>
				</div>
			</div>

			<div class="row">
				<?php $__currentLoopData = $offer_ad_position1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $aRow = json_decode($row->desc); ?>
				<div class="col-lg-4">
					<div class="offer-card" style="background:<?php echo e($aRow->bg_color == '' ? '#daeac5' : $aRow->bg_color); ?>;">
						<?php if($aRow->text_1 != ''): ?>
						<div class="offer-heading">
							<h2><?php echo e($aRow->text_1); ?></h2>
						</div>
						<?php endif; ?>
						<?php if($aRow->text_1 != ''): ?>
						<div class="offer-body">
							<p><?php echo e($aRow->text_2); ?></p>
						</div>
						<?php endif; ?>
						<div class="offer-footer">
							<?php if($aRow->button_text != ''): ?>
							<a href="<?php echo e($row->url); ?>" class="btn theme-btn" <?php echo e($aRow->target =='' ? '' : "target=".$aRow->target); ?>><?php echo e($aRow->button_text); ?></a>
							<?php endif; ?>
							<div class="offer-image">
								<img src="<?php echo e(asset('public/media/'.$row->image)); ?>" alt="<?php echo e($aRow->text_1); ?>" />
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<?php endif; ?>
	<!-- /Offer Section/ -->

	<!-- Products Section -->
	<?php if($section5->is_publish == 1): ?>
	<section class="section product-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-heading">
						<?php if($section5->desc !=''): ?>
						<h5><?php echo e($section5->desc); ?></h5>
						<?php endif; ?>
						
						<?php if($section5->title !=''): ?>
						<h2><?php echo e($section5->title); ?></h2>
						<?php endif; ?>
					</div>
				</div>
			</div>
		
			<div class="row mb25">
				<div class="col-lg-12">
					<ul class="nav nav-pills tp-tabs" id="pills-tab" role="tablist">
						<?php if($section8->is_publish == 1): ?>
						<li class="nav-item" role="presentation">
							<button class="nav-link active" id="pills-newProducts-tab" data-bs-toggle="pill" data-bs-target="#pills-newProducts" type="button" role="tab" aria-controls="pills-newProducts" aria-selected="true"><?php echo e($section8->title); ?></button>
						</li>
						<?php endif; ?>
						<?php if($section9->is_publish == 1): ?>
						<li class="nav-item" role="presentation">
							<button class="nav-link" id="pills-topSelling-tab" data-bs-toggle="pill" data-bs-target="#pills-topSelling" type="button" role="tab" aria-controls="pills-topSelling" aria-selected="false"><?php echo e($section9->title); ?></button>
						</li>
						<?php endif; ?>
						<?php if($section10->is_publish == 1): ?>
						<li class="nav-item" role="presentation">
							<button class="nav-link" id="pills-trendingProducts-tab" data-bs-toggle="pill" data-bs-target="#pills-trendingProducts" type="button" role="tab" aria-controls="pills-trendingProducts" aria-selected="false"><?php echo e($section10->title); ?></button>
						</li>
						<?php endif; ?>
						<?php if($section11->is_publish == 1): ?>
						<li class="nav-item" role="presentation">
							<button class="nav-link" id="pills-topRated-tab" data-bs-toggle="pill" data-bs-target="#pills-topRated" type="button" role="tab" aria-controls="pills-topRated" aria-selected="false"><?php echo e($section11->title); ?></button>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<div class="tab-content" id="pills-tabContent">
						<!--New Products-->
						<?php if($section8->is_publish == 1): ?>
						<div class="tab-pane fade show active" id="pills-newProducts" role="tabpanel" aria-labelledby="pills-newProducts-tab">
							<div class="row">
								<?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3">
									<div class="item-card">
										<div class="item-image">
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php 
													$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
												?>
											<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
											<?php endif; ?>
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
												<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
											</a>
										</div>
										<div class="item-title">
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
										</div>
										<div class="rating-wrap">
											<div class="stars-outer">
												<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
											</div>
											<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
										</div>
										<div class="item-sold">
											<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
										</div>
										<div class="item-pric-card">
											<?php if($row->sale_price != ''): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
												<?php else: ?>
												<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
												<?php else: ?>
												<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
										</div>
										<div class="item-card-bottom">
											<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
											<ul class="item-cart-list">
												<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
												<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
											</ul>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<?php endif; ?>
						<!--/New Products/-->
					
						<!--Top Selling-->
						<?php if($section9->is_publish == 1): ?>
						<div class="tab-pane fade" id="pills-topSelling" role="tabpanel" aria-labelledby="pills-topSelling-tab">
							<div class="row">
								<?php $__currentLoopData = $top_selling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3">
									<div class="item-card">
										<div class="item-image">
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php 
													$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
												?>
											<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
											<?php endif; ?>
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
												<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
											</a>
										</div>
										<div class="item-title">
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
										</div>
										<div class="rating-wrap">
											<div class="stars-outer">
												<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
											</div>
											<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
										</div>
										<div class="item-sold">
											<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
										</div>
										<div class="item-pric-card">
											<?php if($row->sale_price != ''): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
												<?php else: ?>
												<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
												<?php else: ?>
												<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
										</div>
										<div class="item-card-bottom">
											<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
											<ul class="item-cart-list">
												<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
												<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
											</ul>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<?php endif; ?>
						<!--/Top Selling/-->
						
						<!--Trending Products-->
						<?php if($section10->is_publish == 1): ?>
						<div class="tab-pane fade" id="pills-trendingProducts" role="tabpanel" aria-labelledby="pills-trendingProducts-tab">
							<div class="row">
								<?php $__currentLoopData = $trending_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3">
									<div class="item-card">
										<div class="item-image">
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php 
													$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
												?>
											<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
											<?php endif; ?>
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
												<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
											</a>
										</div>
										<div class="item-title">
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
										</div>
										<div class="rating-wrap">
											<div class="stars-outer">
												<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
											</div>
											<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
										</div>
										<div class="item-sold">
											<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
										</div>
										<div class="item-pric-card">
											<?php if($row->sale_price != ''): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
												<?php else: ?>
												<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
												<?php else: ?>
												<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
										</div>
										<div class="item-card-bottom">
											<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
											<ul class="item-cart-list">
												<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
												<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
											</ul>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<?php endif; ?>
						<!--/Trending Products/-->
						
						<!--Top Rated-->
						<?php if($section11->is_publish == 1): ?>
						<div class="tab-pane fade" id="pills-topRated" role="tabpanel" aria-labelledby="pills-topRated-tab">
							<div class="row">
								<?php $__currentLoopData = $top_rated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3">
									<div class="item-card">
										<div class="item-image">
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php 
													$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
												?>
											<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
											<?php endif; ?>
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
												<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
											</a>
										</div>
										<div class="item-title">
											<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
										</div>
										<div class="rating-wrap">
											<div class="stars-outer">
												<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
											</div>
											<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
										</div>
										<div class="item-sold">
											<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
										</div>
										<div class="item-pric-card">
											<?php if($row->sale_price != ''): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
												<?php else: ?>
												<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
											<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
												<?php if($gtext['currency_position'] == 'left'): ?>
												<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
												<?php else: ?>
												<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
												<?php endif; ?>
											<?php endif; ?>
										</div>
										<div class="item-card-bottom">
											<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
											<ul class="item-cart-list">
												<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
												<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
											</ul>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<?php endif; ?>
						<!--/Top Rated/-->
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Products Section/ -->
	
	<!-- Video Section -->
	<?php if($home_video['is_publish'] == 1): ?>
	<section class="section video-section" style="background-image: url(<?php echo e(asset('public/media/'.$home_video['image'])); ?>);">
		<div class="container">
			<div class="row justify-content-start">
				<div class="col-xl-7 text-center">
					<div class="video-card">
						<a href="<?php echo e($home_video['video_url']); ?>" class="play-icon popup-video">
							<i class="bi bi-play-fill"></i>
						</a>
					</div>
				</div>
				<div class="col-xl-5">
					<div class="video-desc">
						<h1><?php echo e($home_video['title']); ?></h1>
						<?php if($home_video['short_desc'] !=''): ?>
						<p><?php echo e($home_video['short_desc']); ?></p>
						<?php endif; ?>
						<a href="<?php echo e($home_video['url']); ?>" <?php echo e($home_video['target'] =='' ? '' : "target=".$home_video['target']); ?> class="btn theme-btn"><?php echo e($home_video['button_text']); ?></a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Video Section/ -->
	
	<!-- Deals Section -->
	<?php if($section6->is_publish == 1): ?>
	<section class="section deals-section">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section-heading">
						<?php if($section6->desc !=''): ?>
						<h5><?php echo e($section6->desc); ?></h5>
						<?php endif; ?>
						
						<?php if($section6->title !=''): ?>
						<h2><?php echo e($section6->title); ?></h2>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<?php if(count($offer_ad_position2)>0): ?>
				<div class="order-1 col-sm-12 order-sm-1 col-md-4 order-md-1 col-lg-3 order-lg-0">
					<?php $__currentLoopData = $offer_ad_position2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $aRow = json_decode($row->desc); ?>
					<div class="deals-card" style="background:<?php echo e($aRow->bg_color == '' ? '#d7eabf' : $aRow->bg_color); ?>;">
						<img src="<?php echo e(asset('public/media/'.$row->image)); ?>" alt="<?php echo e($aRow->text_1); ?>" />
						<?php if($aRow->text_1 != ''): ?>
						<div class="deals-desc"><?php echo e($aRow->text_1); ?></div>
						<?php endif; ?>
						<div class="deals-bottom">
							<?php if($aRow->button_text != ''): ?>
							<a href="<?php echo e($row->url); ?>" class="btn theme-btn" <?php echo e($aRow->target =='' ? '' : "target=".$aRow->target); ?>><?php echo e($aRow->button_text); ?></a>
							<?php endif; ?>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="order-0 col-sm-12 order-sm-0 col-md-8 order-md-0 col-lg-9 order-lg-1">
				<?php else: ?>
				<div class="order-0 col-sm-12 order-sm-0 col-md-12 order-md-0 col-lg-12 order-lg-1">
				<?php endif; ?>
					<div class="row owl-carousel caro-common deals-carousel">
						<?php $__currentLoopData = $deals_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-12">
							<div class="item-card">
								<div class="item-image">
									<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
										<?php 
											$discount = number_format((($row->old_price - $row->sale_price)*100)/$row->old_price);
										?>
									<span class="item-label"><?php echo e($discount); ?>% <?php echo e(__('Off')); ?></span>
									<?php endif; ?>
									<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>">
										<img src="<?php echo e(asset('public/media/'.$row->f_thumbnail)); ?>" alt="<?php echo e($row->title); ?>" />
									</a>
									<?php if(($row->is_discount == 1) && ($row->end_date !='')): ?>
									<div class="deals-countdown-card">
										<div data-countdown="<?php echo e(date('Y/m/d', strtotime($row->end_date))); ?>" class="deals-countdown"></div>
									</div>
									<?php endif; ?>
								</div>
								<div class="item-title">
									<a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><?php echo e(str_limit($row->title)); ?></a>
								</div>
								<div class="rating-wrap">
									<div class="stars-outer">
										<div class="stars-inner" style="width:<?php echo e($row->ReviewPercentage); ?>%;"></div>
									</div>
									<span class="rating-count">(<?php echo e($row->TotalReview); ?>)</span>
								</div>
								<div class="item-sold">
									<?php echo e(__('Sold By')); ?> <a href="<?php echo e(route('frontend.stores', [$row->seller_id, str_slug($row->shop_url)])); ?>"><?php echo e(str_limit($row->shop_name)); ?></a>
								</div>
								<div class="item-pric-card">
									<?php if($row->sale_price != ''): ?>
										<?php if($gtext['currency_position'] == 'left'): ?>
										<div class="new-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->sale_price)); ?></div>
										<?php else: ?>
										<div class="new-price"><?php echo e(NumberFormat($row->sale_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
										<?php endif; ?>
									<?php endif; ?>
									<?php if(($row->is_discount == 1) && ($row->old_price !='')): ?>
										<?php if($gtext['currency_position'] == 'left'): ?>
										<div class="old-price"><?php echo e($gtext['currency_icon']); ?><?php echo e(NumberFormat($row->old_price)); ?></div>
										<?php else: ?>
										<div class="old-price"><?php echo e(NumberFormat($row->old_price)); ?><?php echo e($gtext['currency_icon']); ?></div>
										<?php endif; ?>
									<?php endif; ?>
								</div>
								<div class="item-card-bottom">
									<a data-id="<?php echo e($row->id); ?>" href="javascript:void(0);" class="btn add-to-cart addtocart"><?php echo e(__('Add To Cart')); ?></a>
									<ul class="item-cart-list">
										<li><a class="addtowishlist" data-id="<?php echo e($row->id); ?>" href="javascript:void(0);"><i class="bi bi-heart"></i></a></li>
										<li><a href="<?php echo e(route('frontend.product', [$row->id, $row->slug])); ?>"><i class="bi bi-eye"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>
	<!-- /Deals Section/ -->
</main><?php /**PATH /home/ayshadia/ecommerce9.ayshadiagnosticcenter.com/resources/views/frontend/partials/homepage1.blade.php ENDPATH**/ ?>