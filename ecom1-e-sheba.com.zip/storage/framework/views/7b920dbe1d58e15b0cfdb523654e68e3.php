
<div class="review-body">
	<?php $__currentLoopData = $pro_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="review-card">
		<div class="review-photo">
			<?php if($row->photo != ''): ?>
			<img src="<?php echo e(asset('public/media/'.$row->photo)); ?>" alt="<?php echo e($row->name); ?>" />
			<?php else: ?>
			<span class="username"><?php echo e(strtoupper(sub_str($row->name, 0, 1))); ?></span>
			<?php endif; ?>
		</div>
		<div class="review-info">
			<div class="author-name"><?php echo e($row->name); ?></div>
			<div class="rating-wrap">
				<div class="stars-outer">
					<div class="stars-inner" style="width:<?php echo e($row->rating); ?>%;"></div>
				</div>
			</div>
			<div class="date"><?php echo e(date('d-m-Y', strtotime($row->created_at))); ?></div>
			<div class="desc">
				<p><?php echo e($row->comments); ?></p>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row mt-15">
	<div class="col-lg-12">
		<?php echo e($pro_reviews->links()); ?>

	</div>
</div>
<?php /**PATH F:\xampp\htdocs\resources\views/frontend/partials/products-reviews-grid.blade.php ENDPATH**/ ?>